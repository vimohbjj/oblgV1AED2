/**
 * Ninguna de las clases de aquí pueden ser modificadas
 */
package interfaz;