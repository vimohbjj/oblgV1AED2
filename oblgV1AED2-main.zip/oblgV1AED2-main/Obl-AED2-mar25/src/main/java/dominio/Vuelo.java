package dominio;

public class Vuelo {
    /*
     String codigoCiudadOrigen
     String codigoCiudadDestino
     String codigoDeVuelo */
    private double combustible;
    private double minutos;
    private double costoEnDolares;
    //private TipoVuelo tipoDeVuelo



}
