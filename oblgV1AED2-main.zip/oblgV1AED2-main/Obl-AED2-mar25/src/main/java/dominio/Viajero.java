package dominio;
import interfaz.Categoria;

import java.util.Comparator;
import java.util.Objects;

public class Viajero implements Comparable<Viajero> {
    private String nombre;
    private int edad;
    private String cedula;
    private String correo;
    private Categoria categoria;

    public Viajero(String cedula) {
        this.cedula = cedula;
    }

    public Viajero(String nombre, int edad, String cedula, String correo, Categoria categoria)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.cedula = cedula;
        this.correo = correo;
        this.categoria = categoria;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }



    public String toString() {
        return cedula + ";" + nombre + ";" + correo + ";" + edad + ";" + categoria ;
    }

    @Override
    public int compareTo(Viajero o) {
        return this.cedula.compareTo(o.cedula);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Viajero viajero = (Viajero) o;
        return Objects.equals(cedula, viajero.cedula);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Viajero viajero = (Viajero) o;
//        return cedula != null && cedula.equals(viajero.cedula);
//    }


    @Override
    public int hashCode() { //Esto va?????????????
        return Objects.hashCode(cedula);
    }
}
