package dominio;

import java.util.Objects;

public class ViajeroPorCorreoWrapper implements Comparable<ViajeroPorCorreoWrapper>{
    private Viajero viajero;

    public ViajeroPorCorreoWrapper(Viajero viajero) {
        this.viajero = viajero;
    }

    public Viajero getViajero() {
        return viajero;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ViajeroPorCorreoWrapper that = (ViajeroPorCorreoWrapper) o;
        return Objects.equals(viajero.getCorreo() , that.viajero.getCorreo() );
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(viajero);
    }

    @Override
    public int compareTo(ViajeroPorCorreoWrapper o) { //PARA QUE CARAJO TENGO OTRO COMPARE TO
        return this.viajero.getCorreo().compareTo(o.viajero.getCorreo());
    }

}
