/**
 * Aca es donde pueden ir las clases de dominio.
 */
package dominio;