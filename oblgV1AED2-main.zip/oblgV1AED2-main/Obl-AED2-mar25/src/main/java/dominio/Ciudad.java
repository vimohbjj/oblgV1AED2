package dominio;

public class Ciudad {
    private String codigo;
    private String nombre;
}
