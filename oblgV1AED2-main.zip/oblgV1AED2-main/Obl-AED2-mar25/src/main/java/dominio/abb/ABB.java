package dominio.abb;

import java.util.Comparator;

public class ABB<T extends Comparable<T>>  {
    private Nodo<T>  raiz;

    private final Comparator<T> comparador; //El final dice que no va a cambiar una vez que se crea

    public ABB(){
        this.raiz = null;
        this.comparador = null;
    }

    public ABB(Comparator<T> comparador){
        this.raiz = null;
        this.comparador = comparador;
    }

    //No le hacemos un constructor porque se crea por defecto uno sin parametros
    //Si llego a agregar en un arbol nulo el agregar se carga de crearlo
    public void agregar(T dato) {
        if(this.raiz == null) {
            this.raiz = new Nodo<T> (dato);
        } else {
            agregar(this.raiz, dato);
        }
    }

    public void agregar(Nodo <T> nodo, T dato){
        if(comparar(nodo.getDato(), dato) < 0){ // Derecha
            if(nodo.getDer() == null){ // Puedo agregar?
                nodo.setDer(new Nodo(dato));
            } else {
                agregar(nodo.getDer(), dato);
            }
        } else {
            if(nodo.getIzq() == null){ // Izquierda
                nodo.setIzq(new Nodo(dato));
            } else {
                agregar(nodo.getIzq(), dato);
            }
        }
    }

    public boolean existe(T dato){
        if(this.raiz == null) {
            return false;
        } else {
            return existe(this.raiz, dato);
        }
    }

    public boolean existe(Nodo<T>  nodo, T dato){
        if(nodo == null) {
            return false;
        }

        if(nodo.getDato().equals(dato)){
            return true;
        }

        if(comparar(nodo.getDato(), dato) < 0){
            return existe(nodo.getDer(), dato);
        } else {
            return existe(nodo.getIzq(), dato);
        }

    }

    public T obtener(T dato){
        if(this.raiz == null) {
            return null;
        } else {
            return obtenerRec(this.raiz, dato);
        }
    }

    public T obtenerRec(Nodo<T>  nodo, T dato){
        if(nodo == null) {
            return null;
        }

        if(nodo.getDato().equals(dato)){
            return nodo.getDato();
        }

        if(comparar(nodo.getDato(), dato) < 0){
            return obtenerRec(nodo.getDer(), dato);
        } else {
            return obtenerRec(nodo.getIzq(), dato);
        }

    }

    public int obtenerCantElementosRecorridos(T dato){
        return obtenerCantElementosRecorridosRec(raiz, dato);
    }

//    public int obtenerCantElementosRecorridosRec(Nodo<T> nodo, T dato){
//        if(nodo == null){
//            return 0;
//        }
//
//        int cant =1;
//        if(nodo.getDato().equals(dato)){
//            return cant;
//        }
//
//        if(comparar(nodo.getDato(), dato) < 0){
//            cant += obtenerCantElementosRecorridosRec(nodo.getDer(), dato);
//        } else {
//            return obtenerCantElementosRecorridosRec(nodo.getIzq(), dato);
//        }
//
//        return cant;
//    }

    public int obtenerCantElementosRecorridosRec(Nodo<T> nodo, T dato){
        if(nodo == null){
            return 0;
        }

        if(nodo.getDato().equals(dato)){
            return 1;
        }

        if(comparar(nodo.getDato(), dato) < 0){
           return 1 + obtenerCantElementosRecorridosRec(nodo.getDer(), dato);
        } else {
            return 1 + obtenerCantElementosRecorridosRec(nodo.getIzq(), dato);
        }

    }



    public void mostrarDesc(){
        mostrarDesc(this.raiz);
    }

    public void mostrarDesc(Nodo<T>  nodo){
        if(nodo != null) {
            mostrarDesc(nodo.getDer());
            System.out.println(nodo.getDato().toString() + " ");
            mostrarDesc(nodo.getIzq());
        }

    }

    public void mostrarAsc(){
        mostrarAsc(this.raiz);
    }

    public void mostrarAsc(Nodo<T>  nodo){
        if(nodo != null) {
            mostrarAsc(nodo.getIzq());
            System.out.println(nodo.getDato().toString() + " ");
            mostrarAsc(nodo.getDer());
        }
    }

    private int comparar(T dato1, T dato2){
        if(comparador != null){
            return comparador.compare(dato1, dato2);
        }
        return dato1.compareTo(dato2);
    }





}
