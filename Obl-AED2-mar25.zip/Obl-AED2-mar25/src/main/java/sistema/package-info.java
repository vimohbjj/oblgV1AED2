/**
 * Aca es donde va su implementación, nada les impide crear sus propios objetos en otros paquetes como dominio
 */
package sistema;