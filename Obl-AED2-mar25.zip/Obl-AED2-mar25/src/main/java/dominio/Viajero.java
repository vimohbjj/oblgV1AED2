package dominio;

public class Viajero {
    private String nombre;
    private int edad;
    private String Cedula;
    private String Correo;
    //Me flata agregar la cateogria

}
